from Packets.Commands.Client.LogicBuyDecoCommand import *
from Packets.Commands.Client.LogicBuyBuildingCommand import *


commands = {

    500: LogicBuyBuildingCommand,
    512: LogicBuyDecoCommand

}