# CoC-5.2.4
First open-source server for Clash Of Clans 5.2.4!

## Requirements
**Python** (3.9 - 3.11)

## Installation
Install CoC client [from here](https://drive.google.com/file/d/1--5Ra7EZX3mpBDN1YMF_opoAHhVK8SnF/view?usp=sharing)

Open CoC folder and run **`pip install requirements.txt`** in your shell

Run **`python main.py`** in your shell

Enjoy the server!

## **P.S MANY COMMANDS AND PACKETS ARENT WORK YET, WAIT TILL UPDATE!**


Core and Crypto by [zzVertigo](https://github.com/zzVertigo?tab=repositories)
